## 0.1.0 - First Release

+ Support for Atom's core language packages:
  - HTML, CSS, SCSS, LESS, SASS
  - JavaScript, CoffeScript, TypeScript
  - Markup, gfm
  - ShellScript, MakeFile
  - PHP, Ruby, Python, Go, Pearl, Java
  - Clojure, Mustache
  - SQL, XML, JSON, YAML, TOML
  - C#, Objective-C, SQL

+ Additional support for:
  - 'language-markdown 0.37.2' by burodepeper
  - 'dart 1.0.1' by dart-atom
  - 'language-kotlin 0.5.0' by alexmt
